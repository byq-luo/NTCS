import csv
import json
import time
from urllib.error import URLError
from urllib.request import urlopen, quote

from ztingz.Time import Time


def getVertexLL():
    vll_dict = {}
    with open("../front/CSV/LL.csv", "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        fieldnames = next(reader)  # 获取数据的第一列，作为后续要转为字典的键名 生成器，next方法获取
        csv_reader = csv.DictReader(f, fieldnames=fieldnames)  # list of keys for the dict 以list的形式存放键名
        for row in csv_reader:
            vll_dict[row['vertex']] = (eval(row['lng']), eval(row['lat']))
    return vll_dict


def getAirportCityDict():
    city_dict = {}
    with open("../front/CSV/Airport.csv", "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        fieldnames = next(reader)  # 获取数据的第一列，作为后续要转为字典的键名 生成器，next方法获取
        csv_reader = csv.DictReader(f, fieldnames=fieldnames)  # list of keys for the dict 以list的形式存放键名
        for row in csv_reader:
            row.pop('')
            row.pop('Address_en')
            city_dict[row['Abbreviation']] = row['Address_cn']
    return city_dict


def getCSV(filename, need_fields: str):
    need_fields = need_fields.split(' ')
    cols = []
    with open("../front/CSV/" + filename, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        all_fields = next(reader)  # 获取数据的第一列，作为后续要转为字典的键名 生成器，next方法获取
        unused_fields = list(set(need_fields) ^ set(all_fields))
        csv_reader = csv.DictReader(f, fieldnames=all_fields)  # list of keys for the dict 以list的形式存放键名
        for row in csv_reader:
            for unused_field in unused_fields:
                row.pop(unused_field)
            cols.append(row)
    return cols


cityDict = getAirportCityDict()
vertex_ll_dict = getVertexLL()


def get_vll(v_name: str):
    try:
        return vertex_ll_dict[v_name]
    except KeyError:
        return None


airline_table = getCSV("Airline.csv", "startCity lastCity Company "
                                      "AirlineCode StartDrome ArriveDrome "
                                      "StartTime ArriveTime Mode")
railway_line_table = getCSV("RailwayLine.csv", "ID Type Station A_Time D_Time")
weight_fields = 'time money transfer comfortable'

url = 'http://api.map.baidu.com/geocoder/v2/'
output = 'json'
ak = '6tAbzFGGRxtA2BPUXLnR8EcxVwDSvzpP '
safe_time = Time(strTime='00:10')-Time(strTime='00:00')


def getLL(address):
    add = quote(address)
    uri = url + '?' + 'address=' + add + '&output=' + output + '&ak=' + ak  # 百度地理编码API
    try:
        req = urlopen(uri)
    except URLError:
        print('*' * 12, address)
        time.sleep(10)
        req = urlopen(uri)
    res = req.read().decode()
    temp = json.loads(res)
    try:
        lng = temp['result']['location']['lng']
        lat = temp['result']['location']['lat']
        level = temp['result']['level']
    except KeyError:
        print('-' * 12, address)
        lng = 0
        lat = 0
        level = '未知'
    return lng, lat, level


def writeLL():
    with open('../front/CSV/RailwayLine.csv', encoding="utf-8-sig") as csvfile:
        rows = csv.reader(csvfile)
        with open('../front/CSV/LL.csv', 'w', newline='') as f:
            writer = csv.writer(f)
            i = 0
            for row in rows:
                if i < 100:
                    i += 1
                    continue
                address = row[3] + '站'
                print(address)
                if address == 'Station站':
                    row.append('lng')
                    row.append('lat')
                    row.append('level')
                else:
                    ll = getLL(address)
                    row.append(ll[0])
                    row.append(ll[1])
                    row.append(ll[2])
                writer.writerow(row)
                i += 1
                if i > 100:
                    break


if __name__ == "__main__":
    print(safe_time)
