from ztingz.Configure import cityDict
from ztingz.Time import Time
from ztingz.Vertex import Vertex


class Airport(Vertex):
    def __init__(self, name: str, abbreviation: str, **kwargs):
        super(Airport, self).__init__(name, **kwargs)
        self._abbreviation = abbreviation

    def getAbbreviation(self):
        return self._abbreviation

    def getCityName(self):
        return cityDict[self.getAbbreviation()]

    def byTo(self, v2: Vertex):
        plane_list = []
        for plane in self.adjacentEdgeIter():
            if plane.getArrive() == v2:
                plane_list.append(plane)
        return plane_list

    def bestByTo(self, v2: Vertex, departure_time: Time):
        ways = self.byTo(v2)
        weights = []
        for way in ways:
            if way.getStartTime() > departure_time:
                station_wait = way.getStartTime() - departure_time
            else:
                station_wait = way.getStartTime().nextDay() - departure_time
            weights.append(station_wait + way.getWeight('time'))
        if ways:
            return ways[weights.index(min(weights))], min(weights)
        else:
            return None, None

    def canTakeList(self, departure_time: Time):
        can_take_list = list()
        for plane in self.adjacentEdgeIter():
            if departure_time < plane.getStartTime():
                can_take_list.append(plane)
        return can_take_list


if __name__ == "__main__":
    a = Airport('首都国际机场', 'BJS')
    print(a)
    for item in a.adjacentVerticesIter():
        print(item)
